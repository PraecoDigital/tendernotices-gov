<?php
/**
 * TenderNotices Plugin Test Script
 * 
 * This script tests the plugin structure and files without requiring WordPress
 */

// Mock ABSPATH constant
if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}

echo "=== TenderNotices Plugin Test ===\n\n";

// Test 1: Check if main plugin file exists and is readable
echo "1. Testing main plugin file...\n";
if (file_exists('tender-notices.php')) {
    echo "   ✓ Main plugin file exists\n";
    
    // Check plugin header
    $content = file_get_contents('tender-notices.php');
    if (strpos($content, 'Plugin Name:') !== false) {
        echo "   ✓ Plugin header found\n";
    } else {
        echo "   ⚠ Plugin header may be missing\n";
    }
} else {
    echo "   ✗ Main plugin file not found\n";
}

// Test 2: Check if all required files exist
echo "\n2. Testing required files...\n";
$required_files = [
    'includes/class-post-type.php',
    'includes/class-admin.php', 
    'includes/class-frontend.php',
    'includes/class-shortcode.php',
    'includes/class-widget.php',
    'includes/class-pdf-manager.php',
    'assets/css/tender-notices.css',
    'assets/css/admin.css',
    'assets/js/tender-notices.js',
    'assets/js/admin.js',
    'templates/archive-tender-notice.php',
    'templates/single-tender-notice.php'
];

$all_files_exist = true;
foreach ($required_files as $file) {
    if (file_exists($file)) {
        echo "   ✓ $file\n";
    } else {
        echo "   ✗ $file (missing)\n";
        $all_files_exist = false;
    }
}

// Test 3: Check plugin structure
echo "\n3. Testing plugin structure...\n";
if ($all_files_exist) {
    echo "   ✓ All required files present\n";
} else {
    echo "   ✗ Some required files are missing\n";
}

// Test 4: Check CSS and JS files for syntax
echo "\n4. Testing asset files...\n";

// Check CSS files
$css_files = ['assets/css/tender-notices.css', 'assets/css/admin.css'];
foreach ($css_files as $css_file) {
    if (file_exists($css_file)) {
        $content = file_get_contents($css_file);
        if (strpos($content, '{') !== false && strpos($content, '}') !== false) {
            echo "   ✓ $css_file appears to be valid CSS\n";
        } else {
            echo "   ⚠ $css_file may not be valid CSS\n";
        }
    }
}

// Check JS files
$js_files = ['assets/js/tender-notices.js', 'assets/js/admin.js'];
foreach ($js_files as $js_file) {
    if (file_exists($js_file)) {
        $content = file_get_contents($js_file);
        if (strlen($content) > 0) {
            echo "   ✓ $js_file has content\n";
        } else {
            echo "   ⚠ $js_file appears to be empty\n";
        }
    }
}

echo "\n=== Test Complete ===\n";
echo "The plugin structure appears to be valid for WordPress installation.\n";
echo "To fully test the plugin, you would need:\n";
echo "- A running WordPress installation\n";
echo "- MySQL database\n";
echo "- Web server (Apache/Nginx) or PHP built-in server\n";
